//Types
// primitive data types -> string, number , boolean , undefined , null (type-> object)
// non-primitive -> object (array, object ,......)

//String
let userName: string = "ahmed";
userName = "ali";

let greeting: string = `Hello ${userName}`; //template literal
console.log(greeting);

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz
// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz

//Number
let age: number = 25;
console.log(age);

let temperature: number = 23.5;
let binary: number = 0b1010;
console.log(temperature, binary);

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz
// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz

// Boolean
let isActive: boolean = true;
console.log(isActive);

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz
// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz

let numbers: number[] = [1, 2, 3, 4, 5];
let numbers2: Array<number> = [1, 2, 3, 4, 5];
let words: string[] = ["hello", "world"];

let dynamicArray: Array<any> = [1, "hello", true];

console.log(numbers, numbers2, words, dynamicArray);

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz
// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz

//Any
let dynamicType: any = 10;
dynamicType = "hello";
dynamicType = true;

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz
// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz

//Object
let person: object = { name: "ali", age: 25 };
console.log(person);

let car: { make: string; model: string; year: number } = {
  make: "Toyota",
  model: "Camry",
  year: 2015,
};

console.log(car);

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz
// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz

// Functions
function add(x: number, y: number): void {
  console.log(x + y);
}

console.log(add(5, 5));

//  ?-> optional
//  || value
function greet(name: string, greeting?: string): string {
  return ` ${greeting || "Hello"} , ${name}`;
}

console.log(greet("ali" , "hi"))

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz
// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz


// Union

let id: string | number = 1;
id = "1"
console.log(id)



let userStatus: "active" | "inactive" = "active";
userStatus = "inactive";

let orderStatus : "complete" | "pending" | "refused" = "complete";
console.log(userStatus , orderStatus)