// Interface -> contract
// safety
// auto completion
// clean code

interface UserInterface {
  id: number | string;
  name: string;
  email?: string;
  salary: number;
}

const user1: UserInterface = {
  id: 1,
  name: "ali",
  salary: 2000,
  email: "ali@gmail.com",
};

const user2: UserInterface = {
  id: "2",
  name: "ahmed",
  salary: 5000,
};

console.log(user1, user2);

function printUser(user: UserInterface): void {
  console.log(`${user.name} - ${user.id} - ${user.salary} `);
  if (user.email) {
    console.log(user.email);
  }
}

printUser(user1);
printUser(user2);

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz
// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz

interface PointInterface {
  readonly x: number;
  readonly y: number;
}
const myPoints: PointInterface = {
  x: 10,
  y: 20,
};

console.log(myPoints.x);
console.log(myPoints.y);

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz
// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz

// Indexable types

interface StringArrayInterface {
  [index: number]: string;
}

// Object Indexable type
// interface ColorType {
//   [key: string]: string;
// }
// const color: ColorType = {
//   primaryColor: "red",
//   secondaryColor: "blue",
// };

// ["" , "" ,""]
// index -> number

const myArray: StringArrayInterface = ["ali", "ahmed"];
console.log(myArray);
console.log(myArray[0]);
console.log(myArray[1]);

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz
// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz

interface CarInterface {
  name: string;
  year: number;
}

interface BMWInterface extends CarInterface {
  model: string;
}

const myCar: BMWInterface = {
  name: "BMW",
  model: "C180",
  year: 2013,
};

console.log(myCar);
console.log(myCar.name);
console.log(myCar.model);
console.log(myCar.year);

// zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz

interface MathUtils {
  (a: number, b: number): number;
}
// function sum2(x: number, y: number): number {
//   return x + y;
// }
// function diff(x: number, y: number): number {
//   return x + y;
// }
// function multi(x: number, y: number): number {
//   return x + y;
// }

// params -> 2  -> type: number , return : number
const sum: MathUtils = (x, y) => x + y;
const multi: MathUtils = (x, y) => x * y;
const diff: MathUtils = (x, y) => x - y;
