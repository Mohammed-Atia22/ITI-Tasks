// Interface -> contract
// safety
// auto completion
// clean code
var user1 = {
    id: 1,
    name: "ali",
    salary: 2000,
    email: "ali@gmail.com",
};
var user2 = {
    id: "2",
    name: "ahmed",
    salary: 5000,
};
console.log(user1, user2);
function printUser(user) {
    console.log("".concat(user.name, " - ").concat(user.id, " - ").concat(user.salary, " "));
    if (user.email) {
        console.log(user.email);
    }
}
printUser(user1);
printUser(user2);
var myPoints = {
    x: 10,
    y: 20,
};
console.log(myPoints.x);
console.log(myPoints.y);
// Object Indexable type
// interface ColorType {
//   [key: string]: string;
// }
// const color: ColorType = {
//   primaryColor: "red",
//   secondaryColor: "blue",
// };
// ["" , "" ,""]
// index -> number
var myArray = ["ali", "ahmed"];
console.log(myArray);
console.log(myArray[0]);
console.log(myArray[1]);
var myCar = {
    name: "BMW",
    model: "C180",
    year: 2013,
};
console.log(myCar);
console.log(myCar.name);
console.log(myCar.model);
console.log(myCar.year);
// function sum2(x: number, y: number): number {
//   return x + y;
// }
// function diff(x: number, y: number): number {
//   return x + y;
// }
// function multi(x: number, y: number): number {
//   return x + y;
// }
// params -> 2  -> type: number , return : number
var sum = function (x, y) { return x + y; };
var multi = function (x, y) { return x * y; };
var diff = function (x, y) { return x - y; };
